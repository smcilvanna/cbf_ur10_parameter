% UR10 RL-CBF v2        : Updated 2023.11.24
%
% Run sections in this script to setup and run the simulink model "ur10_NN.slx"
% Must run the first section in this script to setup the ur10 robot model object in the main matlab workspace.
% Then set the user specified obstacle and cbf parameters with the second section., third section randomises the obstacle radius between set max and min values.
%    ** > Note the cbf parameters here are only applied if the manual switch is set in the simulink file, otherwise it will get predicted values from the trained NN block in simulink (see paper)
% The 4th section will run the simulink, or can manually run in simulink.
% 5th section provides some plots for the simulated output.

%% Section 1 - Create robot workspace variable

% Load Robot Model 
ur10            = loadrobot("universalUR10", 'Gravity', [0 0 -9.81] );
ur10.DataFormat = 'row';        % defaults to struct, need to use row to apply configs for playback
open("ur10_NN.slx");            % open the simulink 
replay_rate     = 0.01;         % controls recording rate used for playback below

%% Section 2 - Setup User Specified Parameters

obstacle    = [ 0   ; 1.25  ; 0     ; 0.30 ];     % Static obstacle [ x y z radius]
cbf_parms   = [ 21  ; 11    ; 0.05  ];            % [k1 ; k2 ; pad]

%% Random Obstacle Radius ( after running previous section)

min_obstacle_r = 0.01;  % Set minimum radius
max_obstacle_r = 0.4;   % Set maximum radius
obstacle(4) = randi(100)/100*(max_obstacle_r - min_obstacle_r) + min_obstacle_r;

clearvars min_obstacle_r max_obstacle_r

%% #### RUN PREVIOUS 2 SECTIONS BEFORE THIS!!! ########

% Ensure manual switches are set correctly (inside CBF block) in simulink model :
% Default switches will enable CBF and use NN predicted values.


% Run simulink simulation with above settings
disp("*************************")
disp("Obstacle Radius = " + num2str(obstacle(4)) + newline + "Sim running...");
data = sim("ur10_NN.slx", 'CaptureErrors', 'on');   % Run simulation
disp("Sim completed");
disp("The minimum seperation during this run was : " + min(data.sep_distance));

%% Plot The Single Run with multiple views
close all;
% Data from simulink run
ee_pos = squeeze(data.ee_pos)';
tr_pos = squeeze(data.rec_trj)';

% Plot ee path and trajectory
fig = figure('visible','off');              % change to on to view one fig of run
% desired trajectory
x = tr_pos(:,1); y = tr_pos(:,2); z = tr_pos(:,3);
plot3(x,y,z, ':', Color=[0 0 0.5]+0.2, LineWidth=0.02,MarkerSize=0.01);
hold on;
% ee path
x = ee_pos(:,1); y = ee_pos(:,2); z = ee_pos(:,3);
plot3(x,y,z, LineWidth=2);

ylim([ -0.75 , 1.75 ] );                    % set axis grids even
ylim([ -0.75 , 1.75 ] );
zlim([ -0.75 , 1.75] );

title("End Effector Workspace Position")
xlabel("x position (m)");
ylabel("y position");
zlabel('z position (m)');

grid on;

obs         = data.obstacle(:,:,1);         % read in obstacle data from sim (1 obstacle)
[X,Y,Z]     = sphere(20);                   % create unit sphere
X = X*obs(4);  Y = Y*obs(4); Z = Z*obs(4);  % set radius
surf(X+obs(1),Y+obs(2),Z+obs(3));           % plot at obstacle position
colormap jet;  shading interp;           % apply colourscheme


% Find min sep point

[~, minIdx] = min(data.sep_distance);
x = ee_pos(minIdx,1); y = ee_pos(minIdx,2); z = ee_pos(minIdx,3);

eer = 0.1;                                  % set radius for ee clearance
[X,Y,Z]     = sphere(10);                   % create unit sphere
X = X*eer;  Y = Y*eer; Z = Z*eer;  % set radius
surf(X+x,Y+y,Z+z);           % plot at obstacle position
colormap jet;  shading interp;           % apply colourscheme

ax1 = gca;      % get axis to copy to tiles
cam = campos;   % get camera position to copy to tiles

figure('Renderer', 'painters', 'Position', [10 10 1200   1200]);    % set for svg output and square fig
tlt = tiledlayout(2,2, 'TileSpacing','Compact');

for i = 1:4         % copy the one fig to 4 tiles for multiple views
    copyobj(ax1.Children,nexttile(i)); grid on; nexttile(i);
    ylim([ -0.75 , 1.75 ] ); ylim([ -0.75 , 1.75 ] ); zlim([ -0.75 , 1.75] ); campos(cam);
    xlabel("x(m)"); ylabel("y(m)"); zlabel('z(m)');
end

temp = cbf_parms;
cbf_parms = data.cbf_run_parameters;

% text for subtitle
stxt = "Obstacle Radius :" + num2str(obs(4)) + "  | CBF : k1= " + num2str(cbf_parms(1)) + " k2= " + num2str(cbf_parms(2));

% Adjust individual tiles
nexttile(1)
title("End Effector Workspace Position")
subtitle(stxt)          % Need to manually adjust camera position to best show seperation/collision

nexttile(2)
view(0, 90);
subtitle("XY-View")     % Need to manually adjust camera view to XY

nexttile(3);
view(0,0);
subtitle("XZ-View")

nexttile(4);
view(90,0);
subtitle("YZ-View")

cbf_parms = temp;

clearvars -except ax* fig* data obstacle cbf_parms ur10


