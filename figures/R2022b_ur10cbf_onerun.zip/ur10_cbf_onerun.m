% Load Robot Model 
ur10            = loadrobot("universalUR10", 'Gravity', [0 0 -9.81] );
ur10.DataFormat = 'row';        % defaults to struct, need to use row to apply configs for playback
open("cbfUR10.slx");            % open the simulink 
replay_rate     = 0.01;         % controls recording rate used for playback below

%% Setup Simulation Parameters
obstacle    = [ 0   ; 1.25  ; 0     ; 0.30 ];     % Static obstacle [ x y z radius]
cbf_parms   = [ 21  ; 11    ; 0.05  ];                % [k1 ; k2 ; pad]

%% #### RUN PREVIOUS 2 SECTIONS BEFORE THIS!!! ########

% Run simulink simulation with above settings
disp("*************************")
disp("Obstacle Radius = " + num2str(obstacle(4)) + newline + "Sim running...");
data = sim("cbfUR10.slx", 'CaptureErrors', 'on');   % Run simulation
disp("Sim completed");
disp("The minimum seperation during this run was : " + min(data.sep_distance));

%% Plot The Single Run with multiple views
close all;
% Data from simulink run
ee_pos = squeeze(data.ee_pos)';
tr_pos = squeeze(data.rec_trj)';

% Plot ee path and trajectory
fig = figure('visible','off');              % change to on to view one fig of run
% desired trajectory
x = tr_pos(:,1); y = tr_pos(:,2); z = tr_pos(:,3);
plot3(x,y,z, ':', Color=[0 0 0.5]+0.2, LineWidth=0.02,MarkerSize=0.01);
hold on;
% ee path
x = ee_pos(:,1); y = ee_pos(:,2); z = ee_pos(:,3);
plot3(x,y,z, LineWidth=2);

ylim([ -0.75 , 1.75 ] );                    % set axis grids even
ylim([ -0.75 , 1.75 ] );
zlim([ -0.75 , 1.75] );

title("End Effector Workspace Position")
xlabel("x position (m)");
ylabel("y position");
zlabel('z position (m)');

grid on;

obs         = data.obstacle(:,:,1);         % read in obstacle data from sim (1 obstacle)
[X,Y,Z]     = sphere(20);                   % create unit sphere
X = X*obs(4);  Y = Y*obs(4); Z = Z*obs(4);  % set radius
surf(X+obs(1),Y+obs(2),Z+obs(3));           % plot at obstacle position
colormap jet;  shading interp;           % apply colourscheme


% Find min sep point

[~, minIdx] = min(data.sep_distance);
x = ee_pos(minIdx,1); y = ee_pos(minIdx,2); z = ee_pos(minIdx,3);

eer = 0.1;                                  % set radius for ee clearance
[X,Y,Z]     = sphere(10);                   % create unit sphere
X = X*eer;  Y = Y*eer; Z = Z*eer;  % set radius
surf(X+x,Y+y,Z+z);           % plot at obstacle position
colormap jet;  shading interp;           % apply colourscheme

ax1 = gca;      % get axis to copy to tiles
cam = campos;   % get camera position to copy to tiles

figure('Renderer', 'painters', 'Position', [10 10 1200   1200]);    % set for svg output and square fig
tlt = tiledlayout(2,2, 'TileSpacing','Compact');

for i = 1:4         % copy the one fig to 4 tiles for multiple views
    copyobj(ax1.Children,nexttile(i)); grid on; nexttile(i);
    ylim([ -0.75 , 1.75 ] ); ylim([ -0.75 , 1.75 ] ); zlim([ -0.75 , 1.75] ); campos(cam);
    xlabel("x(m)"); ylabel("y(m)"); zlabel('z(m)');
end

% text for subtitle
stxt = "Obstacle Radius :" + num2str(obs(4)) + "  | CBF : k1= " + num2str(cbf_parms(1)) + " k2= " + num2str(cbf_parms(2));

% Adjust individual tiles
nexttile(1)
title("End Effector Workspace Position")
subtitle(stxt)          % Need to manually adjust camera position to best show seperation/collision

nexttile(2)
view(0, 90);
subtitle("XY-View")     % Need to manually adjust camera view to XY

nexttile(3);
view(0,0);
subtitle("XZ-View")

nexttile(4);
view(90,0);
subtitle("YZ-View")



